﻿namespace PxlFund.Mvc.ProjectSettings
{
    public static class ProgramInfo
    {
        public static class Roles
        {
            public static string ClientRole = "Client";
            public static string AdminRole = "Administrator";
        }
        public static class AdminUser
        {
            public static string UserName = "admin";
            public static string Email = "admin@pxl.be";
            public static string Password = "Adm!n123";
        }
    }
}
