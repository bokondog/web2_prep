﻿namespace PxlFund.Mvc.Data
{
    public class ApplicationDbContext
    {
        //public class ApplicationDbContext : IdentityDbContext
        //{
        //    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        //        : base(options)
        //    {
        //    }
        //}
    }
}
